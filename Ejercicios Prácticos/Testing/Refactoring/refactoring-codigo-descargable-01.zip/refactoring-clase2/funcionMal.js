function miFuncion(parametro){
var mivar1 = 'a';
	var mivar2 = 'b';
	var mivar3 = 'c';
var inicial = 1;
var algo = mivar1;
var otraVariable = 2;
while (inicial < otraVariable){
     inicial = inicial -1;
     		otraVariable = otraVariable;
inicial = inicial +2;
		algo = algo + mivar2
}
if (mivar1 === mivar2){
		mivar3 = mivar2;
}
inicial = 1;
var otraVariable = 2;
while (inicial < otraVariable){
     		inicial = inicial -1;
     	otraVariable = otraVariable;
    		inicial = inicial +2;
            algo = algo + mivar3;
}
var nuevavariable = mivar3;
 	return algo;
}