function devolverABC(parametro){
    var a = 'a';
	var b = 'b';
	var c = 'c';
    var abc = a+b+c;
 	return abc;
}