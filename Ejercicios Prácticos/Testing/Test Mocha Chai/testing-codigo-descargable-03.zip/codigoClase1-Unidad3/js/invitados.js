var Invitados = {
	cantidad: 0,
	nombres: [],
	agregarInvitado: function(nombre){
		this.cantidad +=1;
		this.nombres.push(nombre);
	},
	eliminarUltimoInvitado: function (){
		(this.nombres).pop();
	},
	cuantosInvitadosHay: function(){
		return this.cantidad;
	}
};



