//test para ver si el gato se crea como esperamos
function testPropiedadesDeGatoCorrectas(){
	var miGato = new Gato();
	var nombreDeMiGato = miGato.nombre;
	var generoDeMiGato = miGato.genero;

	return nombreDeMiGato === 'Garfield' && generoDeMiGato === 'macho';
}

//test para ver si no se crean más propiedades que las esperadas
function testCantidadPropiedadesGatoCorrecta(){
	var miGato = new Gato();
	var propiedadesDelGato = Object.keys(miGato);
	return propiedadesDelGato.length == 2;
}

//test para ver si configurarNombre configura el nombre correctamente
function testConfigurarNombre(){
	var miGato = new Gato();
	miGato.configurarNombre('Pedro');
	return miGato.nombre === 'Pedro' && miGato.genero === 'macho';
}

//test para ver si configurarGenero configura correctamente el genero
function testConfigurarGeneroCorrecto(){
	var miGato = new Gato();
	miGato.configurarGenero('hembra');
	return miGato.genero === 'hembra' && miGato.nombre === 'Garfield';
}

//test para ver si configurarGenero no configura el genero si es invalido
function testConfigurarGeneroIncorrecto(){
	var miGato = new Gato();
	miGato.configurarGenero('papa frita');
	return miGato.genero === 'macho';
}

//test para ver si configurarGeneroConHembra configura correctamente el género
function testConfigurarGeneroConHembra(){
	var miGato = new Gato();
	miGato.configurarGeneroConHembra();
	return miGato.genero === 'hembra' && miGato.nombre === 'Garfield';
}

function correrTests(){
	document.getElementById('testPropC').innerHTML = 'testPropiedadesDeGatoCorrectas devuelve ' + '<b>'+testPropiedadesDeGatoCorrectas()+'</b>';
	document.getElementById('testCantP').innerHTML = 'testCantidadPropiedadesGatoCorrecta devuelve ' + '<b>'+testCantidadPropiedadesGatoCorrecta()+'</b>';
	document.getElementById('testConfGC').innerHTML = 'testConfigurarGeneroCorrecto devuelve ' + '<b>'+testConfigurarGeneroCorrecto()+'</b>';
	document.getElementById('testConfN').innerHTML = 'testConfigurarNombre devuelve ' + '<b>'+testConfigurarNombre()+'</b>';
	document.getElementById('testConfGI').innerHTML = 'testConfigurarGeneroIncorrecto devuelve ' + '<b>'+testConfigurarGeneroIncorrecto()+'</b>';
	document.getElementById('testConfGH').innerHTML = 'testConfigurarGeneroConHembra devuelve ' + '<b>'+testConfigurarGeneroConHembra()+'</b>';
}