// define la clase
var Gato = function() {
  this.nombre = 'Garfield';
  this.genero = 'macho';
};


//configura el nombre
Gato.prototype.configurarNombre = function(nombre) {
  this.nombre = nombre;
};


//configura el genero
Gato.prototype.configurarGenero = function(genero) {
	if(genero === 'hembra' || genero === 'macho'){
		this.genero = genero;
	}
};

//configura genero con hembra
Gato.prototype.configurarGeneroConHembra = function() {
  this.configurarGenero('hembra');
};
