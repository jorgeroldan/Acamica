var expect = chai.expect;

describe('Test de suma', function(){
	it('resultado positivo', function(){
		var a = suma(2,3);
		expect(a).to.be.above(0);
	})
	it('resultado negativo', function(){
		var a = suma(-1,-3);
		expect(0).to.be.above(a);
	})
});
